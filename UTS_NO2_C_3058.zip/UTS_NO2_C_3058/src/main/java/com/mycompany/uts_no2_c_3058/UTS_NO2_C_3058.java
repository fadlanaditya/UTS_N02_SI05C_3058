/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3058;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author badnoby
 */
public class UTS_NO2_C_3058 {

    public static void main(String[] args) {
        SalariedEmployee_3058 se_3058 = new SalariedEmployee_3058();
        CommissionEmployee_3058 ce_3058 = new CommissionEmployee_3058();
        ProjectPlanner_3058 pp_3058 = new ProjectPlanner_3058();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3058.Nama_3058 = br.readLine();
            System.out.print("NIP: ");
            se_3058.NIP_3058 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3058.GajiPokok_3058 = Float.parseFloat(br.readLine());
            se_3058.TampilData_3058();
            
            System.out.print("Nama: ");
            ce_3058.Nama_3058 = br.readLine();
            System.out.print("NIP: ");
            ce_3058.NIP_3058 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3058.GajiPokok_3058 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3058.Komisi_3058 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3058.TotalPenjualan_3058 = Float.parseFloat(br.readLine());
            ce_3058.TotalGaji_3058();
            ce_3058.TampilData_3058();
            
            System.out.print("Nama: ");
            pp_3058.Nama_3058 = br.readLine();
            System.out.print("NIP: ");
            pp_3058.NIP_3058 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3058.GajiPokok_3058 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3058.Komisi_3058 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3058.TotalHslProyek_3058 = Float.parseFloat(br.readLine());
            pp_3058.TotalGaji_3058();
            pp_3058.TampilData_3058();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}
