/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3058;

/**
 *
 * @author badnoby
 */
public class CommissionEmployee_3058 extends Employess_3058{
    public float Komisi_3058;
    public float TotalPenjualan_3058;
    public float Totalgaji_3058;
    
    public CommissionEmployee_3058(){
        
    }
    
    public float TotalGaji_3058(){
        Totalgaji_3058 = GajiPokok_3058 + (Komisi_3058 * TotalPenjualan_3058);
        return Totalgaji_3058;
    }
    
    public void TampilData_3058(){
        System.out.println("Commission Employee");
        Tampil_3058();
        System.out.println("Total Gaji: " + Totalgaji_3058);
    }
}
