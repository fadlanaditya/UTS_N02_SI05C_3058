/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3058;

/**
 *
 * @author badnoby
 */
public class Employess_3058{
    
    protected String Nama_3058;
    protected String NIP_3058;
    protected float GajiPokok_3058;
    
    public void Tampil_3058(){
        System.out.println("Nama: " + Nama_3058);
        System.out.println("NIP: " + NIP_3058);
        System.out.println("Gaji Pokok: " + GajiPokok_3058);
    }
}
