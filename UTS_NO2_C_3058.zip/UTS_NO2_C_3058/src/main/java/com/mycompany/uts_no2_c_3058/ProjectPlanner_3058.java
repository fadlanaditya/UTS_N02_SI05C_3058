/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3058;

/**
 *
 * @author badnoby
 */
public class ProjectPlanner_3058 extends Employess_3058{
    public float Komisi_3058;
    public float TotalHslProyek_3058;
    public double Totalgaji_3058;
    
    public ProjectPlanner_3058(){
        
    }
            
    public double TotalGaji_3058(){
        Totalgaji_3058 = GajiPokok_3058 + (Komisi_3058 * TotalHslProyek_3058) - (GajiPokok_3058 *5/100);
        return Totalgaji_3058;
    }
    
    public void TampilData_3058(){
        System.out.println("Project Plannner");
        Tampil_3058();
        System.out.println("Total Gaji: " + Totalgaji_3058);
    }
}
