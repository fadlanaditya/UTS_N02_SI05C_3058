/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3058;

/**
 *
 * @author badnoby
 */
public class SalariedEmployee_3058 extends Employess_3058 {
    public SalariedEmployee_3058(){
        
    }
    
    public void TampilData_3058(){
        System.out.println("Salaried Employee");
        Tampil_3058();
        System.out.println("Total Gaji: " + GajiPokok_3058);
    }
}
